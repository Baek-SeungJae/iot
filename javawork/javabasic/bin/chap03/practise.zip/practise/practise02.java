package chap03.practise;

public class practise02 {

	public static void main(String[] args) {
		int numOfApples = 123;
		int sizeOfBucket = 10;
		int numOfBucket = (numOfApples+sizeOfBucket-1)/sizeOfBucket;
		System.out.println("�ʿ��� �ٱ����� �� : " +numOfBucket);
		
	}

}
