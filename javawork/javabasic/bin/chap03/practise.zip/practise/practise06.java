package chap03.practise;

public class practise06 {

	public static void main(String[] args) {
		int num = 24;
		System.out.println((num+9)/10*10-num);

	}

}
