package chap03.practise;

public class practise07 {

	public static void main(String[] args) {
		int fahrenheit = 100;
		float celcius = (float)5/9 * (fahrenheit-32);
		System.out.println("Fahrenheit : "+fahrenheit);
		System.out.printf("Celcius : %.2f" , celcius);
	}

}
